package main.java.ru.clevertec.check.dao;

import java.util.List;

public interface ProductDAOInt {
    public List<String> readItemInfo();
}
