package main.java.ru.clevertec.check.service;

import main.java.ru.clevertec.check.beans.DiscountCard;

public interface DiscountServiceInt {
    public DiscountCard defineDiscountCard(String[] args);
}
