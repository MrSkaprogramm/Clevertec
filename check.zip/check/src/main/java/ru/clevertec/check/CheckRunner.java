package main.java.ru.clevertec.check;

import main.java.ru.clevertec.check.service.impl.CheckService;

public class CheckRunner {
    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            throw new Exception("ERROR" + "\n" + "BAD REQUEST");
        }

        String arguments = "1-5 2-1 discountCard=1111 balanceDebitCard=1000";

        args = arguments.split(" ");
        CheckService checkService = new CheckService();
        checkService.makeCheck(args);
    }
}
