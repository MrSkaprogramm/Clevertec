package main.java.ru.clevertec.check.dao;

import main.java.ru.clevertec.check.beans.Check;

public interface CheckDAOInt {
    public void saveCheck(Check check);
}
