package main.java.ru.clevertec.check.dao;

import java.util.List;

public interface DiscountDAOInt {
    public List<String> readDiscountCardInfo();
}
